warning off;
clc;
clear all;
tic;
format long;
format compact;

'cec2014'

'DE_rand/1/bin'
% Define the dimension of the problem
   n = 30;
% Set the population size
   popsize = 30;
% Define the search space
   lu = [-100 * ones(1, n); 100 * ones(1, n)];

problemSet = [1  : 30];
for problemIndex = 1 : 30

      problem = problemSet(problemIndex)
      
      % Set the global optimum
      optimum = problem*100;

      outcome = [];  % record the best results
    
      F = 0.9 * ones(popsize, 1);
      CR = 0.5 * ones(popsize, 1);
    
      time = 1;
    
      % The total number of runs
      totalTime = 5;
    
      LB = repmat(lu(1,:), popsize, 1);
      UB = repmat(lu(2,:), popsize, 1);
    
    while time <= totalTime

        rand('seed', sum(100 * clock));

        % Initialize the main population
        popold = repmat(lu(1, :), popsize, 1) + rand(popsize, n) .* (repmat(lu(2, :)-lu(1, :), popsize, 1));
        
        % Evaluate the initial population
        fit = cec14_func(popold', problem);
        fit = fit';    
        
        FES = popsize;
        
        while FES < n * 10000

            pop = popold;      
            fitold = fit;
            
            r0 = [1:popsize];
            [r1, r2, r3] = gnR1R2R3(popsize, r0);
            
            %  == == == == == == == ==  Mutation == == == == == == == == ==
            vi  = pop(r1, :) + F(:, ones(1, n)).* (pop(r2, :) - pop(r3, :));

          
            % == == == == == == == ==  Crossover == == == == == == == == ==
            mask = rand(popsize, n) > CR(:, ones(1, n));                   % mask is used to indicate which elements of ui comes from the parent
            rows = (1:popsize)'; 
            cols = floor(rand(popsize, 1) * n) + 1;   % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([popsize n], rows, cols); 
            mask(jrand) = false;
            ui = vi;  ui(mask) = pop(mask);
            
            % == == == == == == == Boundary repair == == == == == == == ==
            BL  = ui<LB; ui(BL) = 2*LB(BL) - ui(BL);
            BLU = ui(BL)>UB(BL); BL(BL) = BLU; ui(BL) = UB(BL);
            BU  = ui>UB; ui(BU) = 2*UB(BU) - ui(BU);
            BUL = ui(BU)<LB(BU); BU(BU) = BUL; ui(BU) = LB(BU);
            
            % Evaluate the trial vectors
            fitSet = cec14_func(ui', problem);
            fitSet = fitSet';
            
            FES = FES + popsize ; 
            %  == == == == == == == == == Selection == == == == == == == ==  
             for i = 1 : popsize
                if fitold(i) >= fitSet(i)       
                    pop(i, :) = ui(i,:);
                    fit(i, :) = fitSet(i,:);
                end
             end
             
            popold = pop;
            fitold = fit;
  
        end

        outcome = [outcome min(fit-optimum)];

        time = time + 1;

    end
     
    sort(outcome)
    mean(outcome)
    std(outcome)
end
toc;
