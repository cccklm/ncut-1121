#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fmo_lib.h"
#include "Sl_Func.h"

void Hash_sequence(int hash[],int size,int times)
{
  int tg[2], tmp;

  for(int n=0;n<(times*size);n++)
  {
    do{
      for(int a=0;a<2;a++)
        tg[a]=(int)((random()/(pow(2.0,31.0)-1.0))*(double)size);
    }while(tg[0]==tg[1]);
    tmp=hash[tg[0]];
    hash[tg[0]]=hash[tg[1]];
    hash[tg[1]]=tmp;
  }
}

void FMO_initialization(tfish fish[],tstat stat[],int psize,int DIM,double Init_RangeL[],double Init_RangeR[],int sel_func,bool diff_phase)
{
  double temp, seq[5]={1.0, 1.0, 1.0, 0.66, 0.66};//seq[5]={1.0, 0.965, 0.9315, 0.92, 0.92};
  int left, cut, keep;

  for(int p=0;p<psize;p++)
  {
    for(int d=0;d<DIM;d++)
    {
      fish[p].pos[d]=(((random()/(pow(2.0,31.0)-1.0))*(Init_RangeR[sel_func]-Init_RangeL[sel_func]))+Init_RangeL[sel_func]);
      fish[p].pre_pos[d]=(((random()/(pow(2.0,31.0)-1.0))*(Init_RangeR[sel_func]-Init_RangeL[sel_func]))+Init_RangeL[sel_func]);
//      printf("Particle %d, Dimension %d, value %f\n",p,d,fish[p].pos[d]);
    }
    fish[p].eng=Init_ENG;
    fish[p].phase=0;
//    printf("Fish %d passed\n",p);
  }
  fish[psize].val=1e15;

  if(diff_phase)  // If you'd like to set the fish into different phases, the diff_phase should be "true"
  {
    temp=(double)psize/4.32;//temp=(double)psize/4.7365;
    printf("temp=%f\n",temp);
    keep=0;
    left=psize;
    for(int a=0;a<4;a++)
    {
      temp*=seq[a];
      printf("a=%d temp=%f\n",a,temp);
      cut=(int)temp;
      printf("a=%d cut=%d\n",a,cut);
      if((temp-(double)cut)>=0.5)
        cut++;
      left-=cut;
      printf("a=%d cut=%d\n",a,cut);
      printf("a=%d left=%d\n",a,left);
      printf("a=%d keep=%d\n",a,keep);
      for(int b=keep;b<(keep+cut);b++)
      {
        fish[b].phase=a;
        printf("fish[%d].phase=%d\n",b,a);
      }
      keep+=cut;
      printf("a=%d keep=%d\n",a,keep);
    }
    for(int b=keep;b<psize;b++)
    {
      fish[b].phase=4;
      printf("fish[%d].phase=4\n",b);
    }
  }

  // Set the survival rate for each phase (from S[0] to S[3])
  stat[0].fish_S[0]=1.0;
  stat[0].fish_S[1]=1.0;
  stat[0].fish_S[2]=0.66;
  stat[0].fish_S[3]=0.33;
  stat[0].fish_F[0]=0.34;
  stat[0].fish_F[1]=0.64;

/*  
  // Set the survival rate for each phase (from S[0] to S[3])
  stat[0].fish_S[0]=0.965;

  temp=(1.0+exp(Temperature-19.0));
  stat[0].fish_S[1]=(0.817+(0.183/temp));
  if(psize>=1000)
  {
    temp=(1.0+exp(6.5-0.1*Flow_Q));
    stat[0].fish_S[1]*=(0.817+(0.183/temp));
  }

  temp=(1.0+exp(Temperature-19.0));
  for(int x=2;x<4;x++)
    stat[0].fish_S[x]=(0.84+(0.16/temp));

// Set fecundity rate for phase2 to phase4
  stat[0].fish_F[0]=(370.0/1555.0);
  stat[0].fish_F[1]=(1084.0/1555.0);
  // Since stat[0].fish_F[2]=1.0, it doesn't need to be count right here
//*/  
}

void FMO_evaluation(tfish fish[],int psize,int DIM,int sel_func)
{
  double res[1], pop[MAX_DIM];

  for(int p=0;p<psize;p++)
  {
    for(int d=0;d<DIM;d++)
      pop[d]=fish[p].pos[d];

    Solve_Function(sel_func,DIM,pop,res);
    fish[p].val=res[0];

    if(fish[p].val<=fish[psize].val)
    {
      printf("Best Solution Updated.. [ fish[%3d]=%.16f ]\n",p,fish[p].val);
      fish[psize].val=fish[p].val;
      for(int d=0;d<DIM;d++)
        fish[psize].pos[d]=fish[p].pos[d];

      fish[p].eng+=((random()/(pow(2.0,31.0)-1.0))*Init_ENG);
    }
  }

  // Update the energy of every fish
  res[0]=0.0;
  for(int p=0;p<psize;p++)
    res[0]+=fish[p].val;

  for(int p=0;p<psize;p++)
    fish[p].eng-=(fish[p].val/res[0]);
}

void FMO_Eliminate(tfish fish[],int psize,int DIM,int sel_func)
{
  double res[1], pop[MAX_DIM];

  for(int p=0;p<psize;p++)
  {
    if(fish[p].eng<StoppingRatio)
    {
      for(int d=0;d<DIM;d++)
        pop[d]=fish[p].pos[d];

      Solve_Function(sel_func,DIM,pop,res);
      fish[p].val=res[0];

      if(fish[p].val<=fish[psize].val)
      {
        printf("Best Solution Updated.. [ fish[%3d]=%.16f ] Back from Death!!\n",p,fish[p].val);
        fish[psize].val=fish[p].val;
        for(int d=0;d<DIM;d++)
          fish[psize].pos[d]=fish[p].pos[d];

        fish[p].eng+=Init_ENG;//((random()/(pow(2.0,31.0)-1.0))*Init_ENG);
      }
      else
        fish[p].phase=5;
    }
  }
}

void FMO_Fecundity(tfish fish[],tstat stat[],int psize,int DIM)
{
  double temp;
  int left; // The left amount of fishes
  int hash[MAX_DIM];
  int seq_p[(6*MAX_DIM)], phase_count[6]; // The sequence of fishes in different phase, The amount of fish in current phase

  // Count the numbers of fishes in every phase. The 6th type of the fishes should be eliminated.
  for(int a=0;a<6;a++)
    phase_count[a]=0;

  for(int p=0;p<psize;p++)
  {
    seq_p[((fish[p].phase*MAX_DIM)+phase_count[fish[p].phase])]=p;
    phase_count[fish[p].phase]++;
  }

  // Move phase 0 and 1 into 1 and 2
  for(int ph=0;ph<2;ph++)
    for(int x=0;x<phase_count[ph];x++)
      fish[seq_p[(ph*MAX_DIM)+x]].phase=(ph+1);

  // Move phase 2 and 3 and take care the split
  for(int ph=2;ph<4;ph++)
  {
    temp=((double)phase_count[ph]*stat[0].fish_S[ph]);
    left=(int)temp;
    if((temp-(double)left)>=0.5)
      left++;

    for(int n=0;n<phase_count[ph];n++)
      hash[n]=n;
      
    Hash_sequence(hash,phase_count[ph],10);

    for(int x=0;x<left;x++)
      fish[seq_p[((ph*MAX_DIM)+hash[x])]].phase=(ph+1);

    for(int x=left;x<phase_count[ph];x++)
    {
      for(int d=0;d<DIM;d++)
      {
        temp=((random()/(pow(2.0,31.0)-1.0))*(fish[seq_p[((ph*MAX_DIM)+hash[x])]].pos[d]-fish[psize].pos[d]));
        fish[seq_p[((ph*MAX_DIM)+hash[x])]].pos[d]=temp+fish[psize].pos[d];
      }
      fish[seq_p[((ph*MAX_DIM)+hash[x])]].phase=0;
    }
  }

  // Move phase 4 back to 0
  for(int x=0;x<phase_count[4];x++)
    fish[seq_p[(4*MAX_DIM)+x]].phase=0;

}

/*
void FMO_Fecundity(tfish fish[],tstat stat[],int psize)
{
  // Records the sequence of the phases of  the fishes belong to in seq_p
  int seq_p[(6*MAX_DIM)], *hash;
  double temp;
  int GrowNum[5], phase_count[6], fecundity[2]; // The amount of fish in every phase after growing up
                                                // The amount of fish in current phase
                                                // The amount of fish to go into fecundity

  // Count the numbers of fishes in every phase. The 6th type of the fishes should be eliminated.
  for(int a=0;a<6;a++)
    phase_count[a]=0;

  for(int p=0;p<psize;p++)
  {
    seq_p[((fish[p].phase*MAX_DIM)+phase_count[fish[p].phase])]=p;
    phase_count[fish[p].phase]++;
  }

  // Calculate the left fishes to move into the next phase
  for(int a=0;a<4;a++)
  {
    temp=(stat[0].fish_S[a]*(double)phase_count[a]);
    GrowNum[a]=(int)temp;
    if((temp-(double)GrowNum[a])>=0.5)
      GrowNum[a]++;
  }
  GrowNum[4]=(phase_count[4]+phase_count[5]);

  // Calculate the fishes go into Fecundity in phase 2 and 3
  temp=0.0;
  for(int b=0;b<2;b++)
  {
    temp+=(stat[0].fish_F[b]*(double)phase_count[2+b]);
    fecundity[b]=(int)temp;
    if((temp-(double)fecundity[b])>=0.5)
      fecundity[b]++;

    if(GrowNum[4]<fecundity[b])  // If the number of fishes from phase 4 is less than the fecundated fishes, the fecundated fishes in phase 2 and 3 take place of those from phase 4. (Just in case)
    {
      fecundity[b]=GrowNum[4];
      GrowNum[4]=0;
    }
    else
      GrowNum[4]-=fecundity[b];
  }

  // Take care of the grow up process from phase 0 to 3
  for(int ph=0;ph<4;ph++)
  {
    hash=(int *)malloc(sizeof(int)*phase_count[ph]);

    for(int a=0;a<phase_count[ph];a++)
      hash[a]=a;

    Hash_sequence(hash,phase_count[ph],10);

    for(int p=0;p<GrowNum)

    free(hash);
  }
}
//*/

void FMO_movement(tfish fish[],int psize,int DIM,double fish_a,double fish_b,double fish_x)
{
  double ori_speed, consumption;

  for(int p=0;p<psize;p++)
  {
    if(fish[p].eng>MAX_dE)  // If the left energy of this fish is larger than the minimum required energy, take the limited consumption
      consumption=((random()/(pow(2.0,31.0)-1.0))*MAX_dE);
    else                    // otherwise, let the fish swim for the last trip
      consumption=((random()/(pow(2.0,31.0)-1.0))*fish[p].eng);

    for(int d=0;d<DIM;d++)
    {
      ori_speed=(fish[p].pos[d]-fish[p].pre_pos[d]);  // Take the difference between the previous position and the current one
      if((random()/(pow(2.0,31.0)-1.0))>=0.5)         // Randomly change it into minus
        ori_speed*=(-1.0);
      fish[p].pre_pos[d]=fish[p].pos[d];              // Record the current position to replace the previous one
      fish[p].dis[d]=((consumption*ori_speed)/(fish_a+(fish_b*pow(ori_speed,fish_x)))); // The movement formula
      fish[p].pos[d]+=fish[p].dis[d];                 // Update the position
    }
  }
}
