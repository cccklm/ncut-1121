// 02/09/2005
#include <math.h>
#include <stdio.h>

#include "Sl_Func.h"

int Solve_Function(int sel,int dim,double pop[],double res[])
{
  int floor, fcnum;
  double tmp, sub[4];

  tmp=0.0;

  if(sel==0)
  {
    for(int a=1;a<dim;a++)
      tmp+=(100.0*(pow((pop[a]-pow(pop[a-1],2.0)),2.0))+pow((pop[a-1]-1.0),2.0));
    res[0]=tmp;
    fcnum=0;
  }
  else if(sel==1)
  {
    for(int a=0;a<dim;a++)
      tmp+=(pow(pop[a],2.0)-(10*cos(pow((2.0*PIE*pop[a]),2.0)))+10.0);
    res[0]=tmp;
    fcnum=1;
  }
  else //if(sel==2)
  {
    sub[0]=0.0;
    sub[1]=1.0;
    for(int a=0;a<dim;a++)
    {
      sub[0]+=pow(pop[a],2.0);
      sub[1]*=cos((pop[a]/sqrt(double(a+1))));
    }
    tmp=(sub[0]/400.0)-sub[1]+1.0;
    res[0]=tmp;
    fcnum=2;
  }
  
  return fcnum;
}
