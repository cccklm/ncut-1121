/******************************************/
/***        Author: Pei-Wei Tsai        ***/
/***   E-mail: pwtsai@bit.kuas.edu.tw   ***/
/***         Version: 1.0.0.0           ***/
/***         Date: 2008/10/07           ***/
/***    Fish Migration Optimization     ***/
/***    Max Dimension support to 100    ***/
/***                                    ***/
/***      Random: Use "srand(SEED)"     ***/
/******************************************/

#define MAX_DIM       100     // The maximum acceptable dimension
#define Init_ENG      200.0   // The initial energy for every fish
#define MAX_dE        2.0     // The maxima vary energy for each dimension
//#define Male_Ratio    0.5     // The sexual ratio between male to female
#define Temperature   19.0    // The temperature setting in Celsius
#define Flow_Q        75.0    // The flow rate of the water
#define StoppingRatio MAX_dE  // Minima required energy for surviving
#define GrowGNR       20      // Fishes grow up to the next phase per GrowGNR generations

#ifndef TAGFMO
#define TAGFMO

typedef struct tagfmo{

  double pos[MAX_DIM];        // Record the cat's position
  double pre_pos[MAX_DIM];    // Last Position
  double val;                 // Fitness value, which is evaluated by the fitness function
  double eng;                 // Energy of this fish
  double dis[MAX_DIM];        // Moving distances in M-dimension
  int phase;                  // Denotes the growing status of the fish (from 0 to 4)

} tfish;

typedef struct tagstat{

  double fish_S[4];           // The survival rates of every change between phases
  double fish_F[2];           // The Fecundity rates of phase 2 to 3

} tstat;

void FMO_initialization(tfish fish[],tstat stat[],int psize,int DIM,double Init_RangeL[],double Init_RangeR[],int sel_func,bool diff_phase);
void FMO_evaluation(tfish fish[],int psize,int DIM,int sel_func);
void FMO_Eliminate(tfish fish[],int psize,int DIM,int sel_func);
void FMO_Fecundity(tfish fish[],tstat stat[],int psize,int DIM);
void FMO_movement(tfish fish[],int psize,int DIM,double fish_a,double fish_b,double fish_x);

#endif
