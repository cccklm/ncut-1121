#include "fmo_lib.h"
#include "mytimer.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//#define psize   160
#define FN      3
#define MAXI    2000
#define Cycle   50
//#define DIM     30

#define Pr_A    5.27
#define Pr_B    11.44
#define Pr_X    2.44

void initial_border(double R_bod[],double L_bod[])
{
  L_bod[0]=-50.0;
  R_bod[0]=50.0;
  L_bod[1]=-5.12;
  R_bod[1]=5.12;
  L_bod[2]=-600.0;
  R_bod[2]=600.0;
}

void main()
{
  int psize=160, DIM=30;
  tfish fish[(psize+1)];
  tstat stat[1];
  double R_bod[FN], L_bod[FN];
  FILE *fts, *tms;
  char fname[200], cpname[200];
  double avfit[MAXI], avtim[MAXI];
  double Start, End;

  mytimer *timer;
  timer=mytimer_create();

  for(int a=0;a<MAXI;a++)
  {
    avfit[a]=0.0;
    avtim[a]=0.0;
  }

/*
  do{
    printf("\n        +------------------------------------------------+");
    printf("\n        +          Select the Function to Solve          +");
    printf("\n        +------------------------------------------------+");
    printf("\n        ++++++++++    (1) Function 1    **      ++++++++++");
    printf("\n        ++++++++++    (2) Function 2    **      ++++++++++");
    printf("\n        ++++++++++    (3) Function 3    **      ++++++++++");
    printf("\n        +------------------------------------------------+");
    printf("\n\nYour Choice is: ");
    scanf("%d",&chs);
    chs--;
    printf("\n\n");
  }while((chs<0)||(chs>2));
//*/

  initial_border(R_bod,L_bod);

  mytimer_start(timer);

  for(int fncc=0;fncc<FN;fncc++)
  {
    sprintf(fname,"FMO_F%d.txt",fncc);
    sprintf(cpname,"FMO_F%d_time.txt",fncc);
//    printf("Function %d Selected\n",fncc);

    for(int cyc=1;cyc<=Cycle;cyc++)
    {
      srand(cyc);

      mytimer_hold(timer,1);
//      printf("Preparing to Initialize the program...\n");

//      FMO_initialization(fish,stat,psize,DIM,L_bod,R_bod,fncc,0);
      FMO_initialization(fish,stat,psize,DIM,L_bod,R_bod,fncc,1);

      printf("FMO Initizlized..\n");

      for(int itn=1;itn<=MAXI;itn++)
      {
        FMO_evaluation(fish,psize,DIM,fncc);
        FMO_Eliminate(fish,psize,DIM,fncc);
        FMO_Fecundity(fish,stat,psize,DIM);
        FMO_movement(fish,psize,DIM,Pr_A,Pr_B,Pr_X);

        mytimer_hold(timer,2);
        Start=mytimer_get_hold(timer,1);
        End=mytimer_get_hold(timer,2);
        avtim[itn-1]+=(End-Start);
        avfit[itn-1]+=fish[psize].val;

        if((itn%200==0)||(itn==1))
        {
          printf("Best= %.16f on Cycle %d Iteration %d\n",fish[psize].val,cyc,itn);
/*
            for(int d=0;d<DIM;d++)
            {
              printf("%f ",cat[psize].pos[d]);
              if(d>0 && (d+1)%5==0)
                printf("\n");
            }
//*/
        }
      }
      printf("==========================================================\n");
    }
    mytimer_stop(timer);
    printf("\nThe average final fitness value=%.16f\n",(avfit[(MAXI-1)]/Cycle));
    printf("Thank you for excuting the program!\n\n");

    fts=fopen(fname,"w");
    tms=fopen(cpname,"w");
    for(int i=0;i<MAXI;i++)
    {
      fprintf(fts,"%.16f\n",(avfit[i]/Cycle));
      fprintf(tms,"%.16f\n",(avtim[i]/Cycle));
    }

///*
    fprintf(fts,"\n\n================================\n");
    for(int d=0;d<DIM;d++)
    {
      printf("%f ",fish[psize].pos[d]);
      fprintf(fts,"%.16f ",fish[psize].pos[d]);
      if(d>0 && (d+1)%5==0)
      {
        fprintf(fts,"\n");
        printf("\n");
      }
    }
  }
//*/

  mytimer_free(timer);
  fclose(fts);
  fclose(tms);
  return 0;
}
