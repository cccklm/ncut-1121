#ifndef SlFunc
#define SlFunc

#define PIE   3.141592653589793238462643383279

int Solve_Function(int sel,int dim,double pop[],double res[]);

#endif

