function [gbest_fit,gbest_pos,Convergence_curve] = TA(fhd,ps,dim,lb,ub,Max_iteration,varargin)
    rand('twister',mod(floor(now*8640000),2^31-1)); 
    %��ʼ��
    X=initialization(ps,dim,ub,lb); %����λ��
    X_fit = zeros(1,ps);%������Ӧ��
    gbest_fit = inf;%׳��λ��
    gbest_pos = zeros(1,dim);
    Convergence_curve=zeros(1,Max_iteration); %���ڻ�������
    pbest_val = zeros(ps,1);
    for i=1:ps
        X_fit(i) = feval(fhd,X(i,:)',varargin{:});
        pbest_val(i) = X_fit(i);
        if i==1
            gbest_fit = X_fit(i);
            gbest_pos = X(i,:);
        else
            if X_fit(i) < gbest_fit
                gbest_fit = X_fit(i);
                gbest_pos = X(i,:);
            end
        end
    end
    % Main Loop
    iter = 1;
    while iter <= Max_iteration
        t = 2;
        r1=t-iter*((t)/Max_iteration); % r1 decreases linearly from a to 0
        %���������׶�
        for i = 1:ps
            v = unifrnd(lb,ub,1,dim); %�����ʼһ���ٶ�
            for j=1:dim
                if mod(iter,50) <= 25
                    X(i,j) = X(i,j) + r1*(gbest_pos(j)-X(i,j))+ rand*0.1/(X_fit(i)/sum(X_fit)+1); %0.1
                else
                    %���Ӵ���
                    X(i,j) = gbest_pos(j) + v(1,j)*iter/Max_iteration;
                end
            end
            Flag4ub=X(i,:)>ub;
            Flag4lb=X(i,:)<lb;
%             X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+(lb+(ub-lb).*rand(1,dim)).*(Flag4lb+Flag4ub);
            X_fit(i) = feval(fhd,X(i,:)',varargin{:});
        end
        for i=1:ps
            if X_fit(i) < gbest_fit
                gbest_fit = X_fit(i);
                gbest_pos = X(i,:);
            end
        end
        if mod(iter,50)==0
            display(['At iteration ', num2str(iter), ' the optimum is ', num2str(gbest_fit)]);
        end
        Convergence_curve(iter)=gbest_fit;
        iter = iter + 1;
    end
end