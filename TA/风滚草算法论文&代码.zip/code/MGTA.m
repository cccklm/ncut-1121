function [gbest_fit,gbest_pos,Convergence_curve] = MGTA(fhd,ps,dim,lb,ub,Max_iteration,varargin)
    Convergence_curve = zeros(1,Max_iteration);
    X_fit = zeros(1,ps);%������Ӧ��
    gbest_fit = inf;%���׳����Ӧ��
    gbest_pos = zeros(1,dim);%���׳��λ��
    K = 3; %�������ĵ�ĸ�����Ҫ�ֳɵ���Ⱥ��������
    Ds = 25;
    cycle = 50;
    %% ��Ⱥ��ʼ���Լ���Ӧ�ȼ���
    X=initialization(ps,dim,ub,lb); %����λ��
    for i = 1:ps
        X_fit(i) = feval(fhd,X(i,:)',varargin{:});
        if i==1
            gbest_fit = X_fit(i);
            gbest_pos = X(i,:);
        else
            if X_fit(i) < gbest_fit
                gbest_fit = X_fit(i);
                gbest_pos = X(i,:);
            end
        end
    end
    %% ��������Ⱥ����
    Group=repmat(struct('X',{},'fit',{},'pbest',{},'pbestval',{}),1,K);
%     [Idx,~,~,~]=kmeans(X_fit',K,'Replicates',3); %clusteing ����Ӧ�Ⱦ���
    [Idx,C,sumD,D]=kmeans(X,K,'Replicates',3); %clusteing ��λ�þ���
    counter = zeros(1,K);
    for i = 1:ps
        for k=1:K
            if Idx(i) == k
                counter(k) = counter(k) + 1;
                Group(k).X(counter(k),:) = X(i,:);
                Group(k).fit(counter(k),:) = X_fit(i);
                if counter(k) == 1
                    Group(k).pbest = X(i,:);
                    Group(k).pbestval = X_fit(i);
                else
                    if Group(k).pbestval > X_fit(i)
                        Group(k).pbest = X(i,:);
                        Group(k).pbestval = X_fit(i);
                    end
                end
                break;
            end
        end
    end
%     disp(counter);
    Convergence_curve(1) = gbest_fit;
    for iter = 2:Max_iteration
        t = 2;
%         r1=t-iter*((t)/Max_iteration); % r1 decreases linearly from t to 0
        grow_iter = mod(iter,50);
        if grow_iter <= Ds %����ƶ���ʽ
            score = zeros(1,K);
            for k=1:K
                score(k) = Group(k).pbestval;
            end
            [~,index] = sort(score); %����
            for k=1:K
                [~,min_index] = sort(Group(index(k)).fit); %����Ӧ�Ȱ��մ�С��������
                Fit_inver = 1./Group(index(k)).fit;
                P = Fit_inver/sum(Fit_inver);
                Pc = cumsum(P',2); %�����ۻ�����
                r1=t-grow_iter*((t)/cycle);
                ps_g = counter(index(k));
                for i=1:ps_g
                    if min_index(i) < ps_g / 2 || (min_index(i) >= ps_g / 2 && P(i) > rand)
                        for j=1:dim
                            c = 2*(rand(1,3));
                            if k == 1 
                                weight = (c(1)*(Group(index(k)).pbest(j)-Group(index(k)).X(i,j))+c(2)*(gbest_pos(j) - Group(index(k)).X(i,j))+c(3)*(Group(index(2)).pbest(j) - Group(index(k)).X(i,j)))/3;
                            elseif k == K
                                weight = (c(1)*(Group(index(K-1)).pbest(j) - Group(index(k)).X(i,j))+c(2)*(Group(index(k)).pbest(j)-Group(index(k)).X(i,j)))/2;
                            else
                                weight = (c(1)*(Group(index(k)).pbest(j)-Group(index(k)).X(i,j))+c(2)*(Group(index(k-1)).pbest(j) - Group(index(k)).X(i,j))+c(3)*(Group(index(k+1)).pbest(j) - Group(index(k)).X(i,j)))/3;
                            end 
    %            
                                Group(index(k)).X(i,j) = Group(index(k)).X(i,j) + r1*(weight) ;
                        end
                    else
                        tar = find(Pc >= rand);
                        rand_index = tar(1);
                        for j = 1:dim
                            c = rand(1,2);
                            Group(index(k)).X(i,j) = Group(index(k)).X(i,j) + r1*(c(1)*(Group(index(k)).pbest(j)-Group(index(k)).X(i,j))+c(2)*(Group(index(k)).X(rand_index,j)-Group(index(k)).X(i,j)));
                        end
                    end
                    
                    Flag4ub=Group(index(k)).X(i,:)>ub;
                    Flag4lb=Group(index(k)).X(i,:)<lb;
                    Group(index(k)).X(i,:)=(Group(index(k)).X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb; %�߽紦����ʽ1
                    Group(index(k)).fit(i) = feval(fhd,Group(index(k)).X(i,:)',varargin{:});
                end
                [new_pfit,index1] = min(Group(index(k)).fit);
                if new_pfit < Group(index(k)).pbestval
                    Group(index(k)).pbestval = new_pfit;
                    Group(index(k)).pbest = Group(index(k)).X(index1,:);
                    if new_pfit <gbest_fit
                        gbest_fit = new_pfit;
                        gbest_pos = Group(index(k)).X(index1,:);
                    end
                end
            end
        else %���������׶� 
            for k=1:K
                ps_g = counter(k);
                for i=1:ps_g
                    v = unifrnd(lb,ub,1,dim); %�����ʼһ���ٶ�  �ٶȷ�Χ�ĵ���
                    for j=1:dim
                        Group(k).X(i,j) = Group(k).pbest(j) + v(1,j)*(cycle-grow_iter)/cycle;  
                    end
                    Flag4ub=Group(k).X(i,:)>ub;
                    Flag4lb=Group(k).X(i,:)<lb;
                    Group(k).X(i,:)=(Group(k).X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb; %�߽紦����ʽ1
                    Group(k).fit(i) = feval(fhd,Group(k).X(i,:)',varargin{:});
                end
                [new_pfit,index] = min(Group(k).fit);
                if new_pfit < Group(k).pbestval
                    Group(k).pbestval = new_pfit;
                    Group(k).pbest = Group(k).X(index,:);
                    if new_pfit <gbest_fit
                        gbest_fit = new_pfit;
                        gbest_pos = Group(k).X(index,:);
                    end
                end
            end
        end
        if mod(iter,50) == 49
            X = [];
            for i=1:K
                X = [X;cell2mat({Group(i).X})];
                Group(i).X = [];
                Group(i).fit = [];
            end
%             [Idx,~,~,~]=kmeans(X_fit',K,'Replicates',3); %clusteing ����Ӧ�Ⱦ���
            [Idx,~,~,~]=kmeans(X,K,'Replicates',3); %clusteing ��λ�þ���
            counter = zeros(1,K);
            for i = 1:ps
                for k=1:K
                    if Idx(i) == k
                        counter(k) = counter(k) + 1;
                        Group(k).X(counter(k),:) = X(i,:);
                        Group(k).fit(counter(k),:) = X_fit(i);
                        if counter(k) == 1
                            Group(k).pbest = X(i,:);
                            Group(k).pbestval = X_fit(i);
                        else
                            if Group(k).pbestval > X_fit(i)
                                Group(k).pbest = X(i,:);
                                Group(k).pbestval = X_fit(i);
                            end
                        end
                        break;
                    end
                end
            end
        end
        if mod(iter,50)==0
            display(['At iteration ', num2str(iter), ' the optimum is ', num2str(gbest_fit)]);
        end
        Convergence_curve(iter) = gbest_fit;
        
    end
    
end