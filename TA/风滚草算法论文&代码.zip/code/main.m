clear all 
clc

SearchAgents_no=30; % Number of search agents
fun_num = 1;
fhd=str2func('cec13_func');
lb=-100;
ub=100;
Max_iteration=1000; % Maximum numbef of iterations
dim = 30;
% Load details of the selected benchmark function
targetbest = [-1400;-1300;-1200;-1100;-1000;-900;-800;-700;-600;-500;-400;-300;
    -200;-100;100;200;300;400;500;600;700;800;900;1000;1100;1200;1300;1400];
[Best_score,Best_pos,cg_curve]=TA(fhd,SearchAgents_no,dim,lb,ub,Max_iteration,fun_num);

plot(cg_curve,'b')
title('Convergence curve')
xlabel('Iteration');
ylabel('Best flame (score) obtained so far');
legend('TA')

display(['The best optimal value of the objective funciton found by TA is : ', num2str(Best_score-targetbest(fun_num))]);